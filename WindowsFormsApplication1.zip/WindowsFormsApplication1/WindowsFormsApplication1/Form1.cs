﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                string s = textBox1.Text;
                Vigenere.key = Vigenere.Generate_Pseudorandom_KeyWord(s.Length);
                textBox3.Text = Vigenere.key;
                textBox1.Text = Vigenere.encrypt(s, Vigenere.key, 1);
            }
            else
                MessageBox.Show("Введите ключевое слово!");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                string s = textBox1.Text;
                textBox1.Text = Vigenere.encrypt(s, Vigenere.key, -1);
            }
            else
                MessageBox.Show("Введите ключевое слово!");

        }
        
    }
}
